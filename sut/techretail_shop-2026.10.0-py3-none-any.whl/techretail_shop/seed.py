"""Seedad testdata. Alla namn och adresser är påhittade.

Testkonton (lösenord för alla: Test1234!):
    kund@example.com   Kim Kund     – standardkund med två ordrar
    kund2@example.com  Robin Ring   – annan kund med två ordrar
    ny@example.com     Noa Ny       – ny kund utan ordrar
    last@example.com   Lo Låst      – låst konto, inloggning nekas
"""

from __future__ import annotations

import sqlite3

from .security import hash_password

TEST_PASSWORD = "Test1234!"

USERS = [
    (1, "kund@example.com", "Kim Kund", 0),
    (2, "kund2@example.com", "Robin Ring", 0),
    (3, "ny@example.com", "Noa Ny", 0),
    (4, "last@example.com", "Lo Låst", 1),
]

CATEGORIES = [
    (1, "verktyg", "Verktyg"),
    (2, "el-belysning", "El och belysning"),
    (3, "hemteknik", "Hemteknik"),
]

# (id, sku, namn, beskrivning, pris i öre, kategori, lager)
PRODUCTS = [
    (1, "VT-1001", "Skruvdragare 18 V", "Kompakt borr- och skruvdragare med två batterier och laddare.", 149900, 1, 25),
    (2, "VT-1002", "Slagborrmaskin 750 W", "Kraftig slagborr för betong och tegel. Djupstopp ingår.", 89900, 1, 12),
    (3, "VT-1003", "Bitsats 32 delar", "Bits i härdat stål med magnetisk hållare.", 19900, 1, 80),
    (4, "VT-1004", "Hammare 450 g", "Snickarhammare med glasfiberskaft.", 24900, 1, 40),
    (5, "VT-1005", "Vattenpass 60 cm", "Aluminiumvattenpass med tre libeller.", 17990, 1, 30),
    (6, "VT-1006", "Tumstock 2 m", "Klassisk tumstock i trä, 10 leder.", 8990, 1, 100),
    (7, "VT-1007", "Sticksåg 650 W", "Pendlande sticksåg med verktygsfritt bladbyte.", 79900, 1, 9),
    (8, "VT-1008", "Verktygslåda 22 tum", "Rymlig låda i slagtålig plast med löstagbart fack.", 34900, 1, 18),
    (9, "VT-1009", "Multiverktyg 300 W", "Oscillerande multiverktyg med 20 tillbehör.", 99900, 1, 0),
    (10, "VT-1010", "Skiftnyckel 250 mm", "Krom-vanadin, justerbar upp till 30 mm.", 12900, 1, 55),
    (11, "EL-2001", "LED-lampa E27 806 lm", "Motsvarar 60 W. Varmvit 2700 K.", 4990, 2, 300),
    (12, "EL-2002", "LED-lampa GU10 3-pack", "Dimbar, 345 lm per lampa.", 12900, 2, 120),
    (13, "EL-2003", "Grenuttag 6-vägs", "Jordat grenuttag med strömbrytare, 3 m kabel.", 19900, 2, 60),
    (14, "EL-2004", "Förlängningskabel 10 m", "Gummikabel för utomhusbruk, IP44.", 29900, 2, 35),
    (15, "EL-2005", "Arbetsbelysning LED 20 W", "Uppladdningsbar strålkastare med stativ.", 44900, 2, 22),
    (16, "EL-2006", "Rörelsevakt utomhus", "Styr belysning via rörelse, räckvidd 12 m.", 34900, 2, 15),
    (17, "EL-2007", "Spänningsprovare", "Beröringsfri provare 12–1000 V med ljus och ljud.", 21900, 2, 45),
    (18, "EL-2008", "Takarmatur Nord", "Takarmatur i opalglas, Ø 30 cm.", 59900, 2, 10),
    (19, "EL-2009", "Ljusslinga 10 m", "Ljusslinga med 100 LED för inom- och utomhusbruk.", 24900, 2, 70),
    (20, "EL-2010", "Batterier AA 12-pack", "Alkaliska batterier, lång hållbarhet.", 8990, 2, 200),
    (21, "HT-3001", "Robotdammsugare S5", "Kartlägger hemmet och styrs via app.", 299900, 3, 7),
    (22, "HT-3002", "Smart högtalare Mini", "Kompakt högtalare med röststyrning.", 49900, 3, 33),
    (23, "HT-3003", "Smart kontakt 2-pack", "Styr lampor och apparater via app eller schema.", 29900, 3, 50),
    (24, "HT-3004", "Termometer inne/ute", "Trådlös givare och display med min/max.", 19900, 3, 28),
    (25, "HT-3005", "Brandvarnare optisk", "10 års batteri, testknapp.", 14900, 3, 90),
    (26, "HT-3006", "Dörrklocka med kamera", "Full HD, rörelselarm, tvåvägsljud.", 129900, 3, 11),
    (27, "HT-3007", "Vattenkokare 1,7 l", "Rostfri vattenkokare med temperaturval.", 49990, 3, 26),
    (28, "HT-3008", "Elektrisk tandborste", "Tre lägen, timer och reseetui.", 39900, 3, 40),
    (29, "HT-3009", "Laddare USB-C 65 W", "Snabbladdare med två portar.", 34900, 3, 65),
    (30, "HT-3010", "Hörlurar trådlösa", "Brusreducering och 30 timmars batteritid.", 149900, 3, 14),
]

IMAGES = {1: "verktyg.svg", 2: "el.svg", 3: "hemteknik.svg"}

DISCOUNT_CODES = [
    ("TECH10", 10, 1, "10 % på hela köpet"),
    ("VINTER15", 15, 1, "15 % vinterrabatt"),
    ("SOMMAR20", 20, 0, "Utgången sommarkampanj"),
]

# Ordrar: (id, user_id, datum, status, namn, adress, postnr, ort, betalning, rabattkod, rader)
ORDERS = [
    (1001, 1, "2026-09-02", "Levererad", "Kim Kund", "Testgatan 1", "111 22", "Exempelstad", "kort", None, [(3, 1), (11, 4)]),
    (1002, 2, "2026-09-05", "Levererad", "Robin Ring", "Provvägen 7", "222 33", "Övningsby", "faktura", "TECH10", [(21, 1)]),
    (1003, 1, "2026-10-01", "Skickad", "Kim Kund", "Testgatan 1", "111 22", "Exempelstad", "kort", None, [(1, 1)]),
    (1004, 2, "2026-10-12", "Behandlas", "Robin Ring", "Provvägen 7", "222 33", "Övningsby", "kort", None, [(13, 2), (17, 1)]),
]


def _rating_rows():
    rows = []
    review_id = 1
    for product_id, *_ in PRODUCTS:
        for i in range(product_id % 4 + 1):
            rows.append((review_id, product_id, 3 + (product_id + i) % 3))
            review_id += 1
    return rows


def seed(raw: sqlite3.Connection) -> None:
    from .pricing import order_totals

    raw.executemany(
        "INSERT INTO users (id, email, name, password_hash, locked) VALUES (?, ?, ?, ?, ?)",
        [(i, e, n, hash_password(TEST_PASSWORD, salt=f"seed{i}"), locked) for i, e, n, locked in USERS],
    )
    raw.executemany("INSERT INTO categories (id, slug, name) VALUES (?, ?, ?)", CATEGORIES)
    raw.executemany(
        "INSERT INTO products (id, sku, name, description, price_ore, category_id, stock, image) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
        [(*p, IMAGES[p[5]]) for p in PRODUCTS],
    )
    raw.executemany("INSERT INTO reviews (id, product_id, rating) VALUES (?, ?, ?)", _rating_rows())
    raw.executemany("INSERT INTO discount_codes (code, percent, active, description) VALUES (?, ?, ?, ?)", DISCOUNT_CODES)

    prices = {p[0]: (p[2], p[4]) for p in PRODUCTS}
    percents = {c[0]: c[1] for c in DISCOUNT_CODES}
    for oid, uid, date, status, name, addr, zip_, city, pay, code, lines in ORDERS:
        subtotal = sum(prices[pid][1] * qty for pid, qty in lines)
        totals = order_totals(subtotal, percents.get(code, 0), alt_rounding=False)
        raw.execute(
            "INSERT INTO orders (id, user_id, created_at, status, name, address, zip, city, payment, discount_code,"
            " subtotal_ore, discount_ore, shipping_ore, total_ore) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (oid, uid, date, status, name, addr, zip_, city, pay, code,
             totals["subtotal"], totals["discount"], totals["shipping"], totals["total"]),
        )
        raw.executemany(
            "INSERT INTO order_lines (order_id, product_id, name, unit_price_ore, quantity) VALUES (?, ?, ?, ?, ?)",
            [(oid, pid, prices[pid][0], prices[pid][1], qty) for pid, qty in lines],
        )
