"""Endpoints som bara finns i testmiljön (stängs av med TECHRETAIL_TEST_ENDPOINTS=0)."""

from __future__ import annotations

from fastapi import APIRouter, Request

router = APIRouter(prefix="/test", tags=["test"])


@router.post("/reset", summary="Återställ databasen till seedad testdata")
def reset(request: Request):
    request.app.state.db.initialize(force_reset=True)
    request.session.clear()
    return {"status": "återställd"}
