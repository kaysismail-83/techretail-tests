"""SQLite-åtkomst med frågeräkning och simulerad nätverkslatens.

Varje HTTP-anrop får en egen anslutning. Som i en riktig databas finns ett
begränsat antal samtidiga anslutningar (poolen, TECHRETAIL_DB_POOL, se app.py). Antalet frågor och den totala tiden i
databasen redovisas i svarshuvudet ``Server-Timing`` (se app.py). Det gör att
antalet frågor syns både i webbläsarens nätverksflik och i k6.
"""

from __future__ import annotations

import sqlite3
import time
from contextvars import ContextVar
from dataclasses import dataclass
from pathlib import Path


@dataclass
class QueryStats:
    count: int = 0
    seconds: float = 0.0


query_stats: ContextVar[QueryStats | None] = ContextVar("query_stats", default=None)


class Conn:
    def __init__(self, raw: sqlite3.Connection, latency_ms: float):
        self.raw = raw
        self.latency_s = max(latency_ms, 0) / 1000

    def _execute(self, sql: str, params=()) -> sqlite3.Cursor:
        start = time.perf_counter()
        if self.latency_s:
            time.sleep(self.latency_s)
        cur = self.raw.execute(sql, params)
        stats = query_stats.get()
        if stats is not None:
            stats.count += 1
            stats.seconds += time.perf_counter() - start
        return cur

    def all(self, sql: str, params=()) -> list[sqlite3.Row]:
        return self._execute(sql, params).fetchall()

    def one(self, sql: str, params=()) -> sqlite3.Row | None:
        return self._execute(sql, params).fetchone()

    def run(self, sql: str, params=()) -> sqlite3.Cursor:
        return self._execute(sql, params)

    def commit(self) -> None:
        self.raw.commit()

    def rollback(self) -> None:
        self.raw.rollback()

    def close(self) -> None:
        self.raw.close()


class Database:
    def __init__(self, path: Path, latency_ms: float = 0.0):
        self.path = Path(path)
        self.latency_ms = latency_ms

    def connect(self) -> Conn:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        raw = sqlite3.connect(self.path, timeout=15, check_same_thread=False)
        raw.row_factory = sqlite3.Row
        raw.execute("PRAGMA foreign_keys = ON")
        raw.execute("PRAGMA busy_timeout = 15000")
        return Conn(raw, self.latency_ms)

    def initialize(self, force_reset: bool = False) -> bool:
        """Skapa schema och seeda om databasen saknas. Returnerar True om den seedades."""
        from .seed import seed

        self.path.parent.mkdir(parents=True, exist_ok=True)
        raw = sqlite3.connect(self.path, timeout=15)
        try:
            raw.execute("PRAGMA journal_mode = WAL")
            exists = raw.execute(
                "SELECT name FROM sqlite_master WHERE type='table' AND name='products'"
            ).fetchone()
            if exists and not force_reset:
                return False
            raw.executescript(DROP_SQL + SCHEMA_SQL)
            seed(raw)
            raw.commit()
            return True
        finally:
            raw.close()


DROP_SQL = """
DROP TABLE IF EXISTS order_lines;
DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS cart_items;
DROP TABLE IF EXISTS carts;
DROP TABLE IF EXISTS discount_codes;
DROP TABLE IF EXISTS reviews;
DROP TABLE IF EXISTS products;
DROP TABLE IF EXISTS categories;
DROP TABLE IF EXISTS tokens;
DROP TABLE IF EXISTS users;
"""

SCHEMA_SQL = """
CREATE TABLE users (
    id INTEGER PRIMARY KEY,
    email TEXT NOT NULL UNIQUE,
    name TEXT NOT NULL,
    password_hash TEXT NOT NULL,
    locked INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE tokens (
    token TEXT PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    expires_at REAL NOT NULL
);
CREATE TABLE categories (
    id INTEGER PRIMARY KEY,
    slug TEXT NOT NULL UNIQUE,
    name TEXT NOT NULL
);
CREATE TABLE products (
    id INTEGER PRIMARY KEY,
    sku TEXT NOT NULL UNIQUE,
    name TEXT NOT NULL,
    description TEXT NOT NULL,
    price_ore INTEGER NOT NULL,
    category_id INTEGER NOT NULL REFERENCES categories(id),
    stock INTEGER NOT NULL,
    image TEXT NOT NULL
);
CREATE TABLE reviews (
    id INTEGER PRIMARY KEY,
    product_id INTEGER NOT NULL REFERENCES products(id),
    rating INTEGER NOT NULL
);
CREATE TABLE discount_codes (
    code TEXT PRIMARY KEY,
    percent INTEGER NOT NULL,
    active INTEGER NOT NULL,
    description TEXT NOT NULL
);
CREATE TABLE carts (
    cart_key TEXT PRIMARY KEY,
    discount_code TEXT REFERENCES discount_codes(code)
);
CREATE TABLE cart_items (
    cart_key TEXT NOT NULL REFERENCES carts(cart_key) ON DELETE CASCADE,
    product_id INTEGER NOT NULL REFERENCES products(id),
    quantity INTEGER NOT NULL,
    PRIMARY KEY (cart_key, product_id)
);
CREATE TABLE orders (
    id INTEGER PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id),
    created_at TEXT NOT NULL,
    status TEXT NOT NULL,
    name TEXT NOT NULL,
    address TEXT NOT NULL,
    zip TEXT NOT NULL,
    city TEXT NOT NULL,
    payment TEXT NOT NULL,
    discount_code TEXT,
    subtotal_ore INTEGER NOT NULL,
    discount_ore INTEGER NOT NULL,
    shipping_ore INTEGER NOT NULL,
    total_ore INTEGER NOT NULL
);
CREATE TABLE order_lines (
    order_id INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
    product_id INTEGER NOT NULL,
    name TEXT NOT NULL,
    unit_price_ore INTEGER NOT NULL,
    quantity INTEGER NOT NULL
);
"""
