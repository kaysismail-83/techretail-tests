"""Webbgränssnittet (server-renderade Jinja2-sidor)."""

from __future__ import annotations

from importlib import resources
from pathlib import Path
from urllib.parse import quote

from fastapi import APIRouter, Depends, Form, Request
from fastapi.responses import HTMLResponse, RedirectResponse, Response
from fastapi.templating import Jinja2Templates

from . import services as s
from .config import Settings
from .db import Conn
from .deps import ensure_anon, get_conn, get_settings
from .pricing import format_sek
from .services import ServiceError, User

router = APIRouter(include_in_schema=False)

templates = Jinja2Templates(directory=Path(str(resources.files("techretail_shop") / "templates")))
templates.env.filters["sek"] = format_sek


def _user(request: Request, conn: Conn) -> User | None:
    uid = request.session.get("user_id")
    return s.get_user(conn, uid) if uid else None


def _key(request: Request, user: User | None) -> str:
    return f"user:{user.id}" if user else f"anon:{ensure_anon(request)}"


def flash(request: Request, message: str, kind: str = "info") -> None:
    request.session.setdefault("flash", []).append({"message": message, "kind": kind})


def render(request: Request, conn: Conn, settings: Settings, name: str, status_code: int = 200, **ctx) -> HTMLResponse:
    user = _user(request, conn)
    key = _key(request, user)
    messages = request.session.pop("flash", [])
    context = {
        "t": settings.texts,
        "settings": settings,
        "on": settings.on,
        "user": user,
        "cart_count": s.item_count(conn, key),
        "messages": messages,
        "path": request.url.path,
        **ctx,
    }
    return templates.TemplateResponse(request, name, context, status_code=status_code)


def redirect(url: str) -> RedirectResponse:
    return RedirectResponse(url, status_code=303)


def login_required(request: Request, conn: Conn) -> User | RedirectResponse:
    user = _user(request, conn)
    if user is None:
        return redirect(f"/logga-in?nasta={quote(request.url.path)}")
    return user


# ------------------------------------------------------------------ sidor

@router.get("/", response_class=HTMLResponse)
def start(request: Request, conn: Conn = Depends(get_conn, scope="function"), settings: Settings = Depends(get_settings)):
    featured = [s.get_product(conn, pid) for pid in (1, 21, 15, 30)]
    return render(request, conn, settings, "start.html", featured=featured, categories=s.list_categories(conn))


def _price(value: str | None) -> float | None:
    if value is None or value.strip() == "":
        return None
    try:
        return float(value.replace(",", ".").replace(" ", ""))
    except ValueError:
        return None


@router.get("/produkter", response_class=HTMLResponse)
def product_list(request: Request, q: str = "", kategori: str = "", min_pris: str = "", max_pris: str = "",
                 sortering: str = "relevans", conn: Conn = Depends(get_conn, scope="function"),
                 settings: Settings = Depends(get_settings)):
    filters = {"q": q, "kategori": kategori, "min_pris": min_pris, "max_pris": max_pris, "sortering": sortering}
    try:
        products = s.search_products(conn, settings, q=q or None, category=kategori or None,
                                     min_price=_price(min_pris), max_price=_price(max_pris), sort=sortering)
        error = None
    except ServiceError as exc:
        products, error = [], exc.message
        return render(request, conn, settings, "products.html", status_code=exc.status_code, products=products,
                      error=error, filters=filters, categories=s.list_categories(conn), sorts=s.SORTS)
    return render(request, conn, settings, "products.html", products=products, error=error, filters=filters,
                  categories=s.list_categories(conn), sorts=s.SORTS)


@router.get("/produkter/{product_id}", response_class=HTMLResponse)
def product_page(request: Request, product_id: int, conn: Conn = Depends(get_conn, scope="function"),
                 settings: Settings = Depends(get_settings)):
    try:
        product = s.get_product(conn, product_id)
    except ServiceError:
        return render(request, conn, settings, "not_found.html", status_code=404)
    return render(request, conn, settings, "product.html", product=product)


@router.post("/kundvagn/lagg-till")
def add_form(request: Request, product_id: int = Form(...), quantity: int = Form(1),
             conn: Conn = Depends(get_conn, scope="function")):
    """Reservväg utan JavaScript. Webbläsare med JavaScript använder /api/cart/items."""
    key = _key(request, _user(request, conn))
    try:
        s.add_to_cart(conn, key, product_id, quantity)
        flash(request, "Varan har lagts i kundvagnen.", "success")
    except ServiceError as exc:
        flash(request, exc.message, "error")
    return redirect(f"/produkter/{product_id}")


# ------------------------------------------------------------------ inloggning

@router.get("/logga-in", response_class=HTMLResponse)
def login_page(request: Request, nasta: str = "/", conn: Conn = Depends(get_conn, scope="function"),
               settings: Settings = Depends(get_settings)):
    return render(request, conn, settings, "login.html", next=_safe_next(nasta), error=None, email="")


def _safe_next(value: str) -> str:
    return value if value.startswith("/") and not value.startswith("//") else "/"


@router.post("/logga-in", response_class=HTMLResponse)
def login_submit(request: Request, email: str = Form(""), password: str = Form(""), nasta: str = Form("/"),
                 conn: Conn = Depends(get_conn, scope="function"), settings: Settings = Depends(get_settings)):
    try:
        user = s.authenticate(conn, email, password)
    except ServiceError as exc:
        message = settings.texts["locked_error"] if exc.status_code == 423 else settings.texts["login_error"]
        return render(request, conn, settings, "login.html", status_code=exc.status_code if exc.status_code != 423 else 403,
                      next=_safe_next(nasta), error=message, email=email)
    anon = request.session.get("anon")
    if anon:
        s.merge_carts(conn, f"anon:{anon}", f"user:{user.id}")
    request.session["user_id"] = user.id
    return redirect(_safe_next(nasta))


@router.post("/logga-ut")
def logout(request: Request):
    request.session.clear()
    return redirect("/")


# ------------------------------------------------------------------ kundvagn

@router.get("/kundvagn", response_class=HTMLResponse)
def cart_page(request: Request, conn: Conn = Depends(get_conn, scope="function"), settings: Settings = Depends(get_settings)):
    key = _key(request, _user(request, conn))
    return render(request, conn, settings, "cart.html", cart=s.get_cart(conn, settings, key))


@router.post("/kundvagn/uppdatera")
def cart_update(request: Request, product_id: int = Form(...), quantity: int = Form(...),
                conn: Conn = Depends(get_conn, scope="function")):
    key = _key(request, _user(request, conn))
    try:
        s.set_quantity(conn, key, product_id, quantity)
    except ServiceError as exc:
        flash(request, exc.message, "error")
    return redirect("/kundvagn")


@router.post("/kundvagn/ta-bort")
def cart_remove(request: Request, product_id: int = Form(...), conn: Conn = Depends(get_conn, scope="function")):
    s.remove_from_cart(conn, _key(request, _user(request, conn)), product_id)
    return redirect("/kundvagn")


@router.post("/kundvagn/rabattkod")
def cart_discount(request: Request, code: str = Form(""), conn: Conn = Depends(get_conn, scope="function"),
                  settings: Settings = Depends(get_settings)):
    key = _key(request, _user(request, conn))
    try:
        result = s.apply_discount_code(conn, key, code)
        flash(request, settings.texts["discount_ok"].format(**result), "success")
    except ServiceError:
        flash(request, settings.texts["discount_invalid"], "error")
    return redirect("/kundvagn")


# ------------------------------------------------------------------ kassa

@router.get("/kassa", response_class=HTMLResponse)
def checkout_page(request: Request, conn: Conn = Depends(get_conn, scope="function"), settings: Settings = Depends(get_settings)):
    user = login_required(request, conn)
    if isinstance(user, Response):
        return user
    cart = s.get_cart(conn, settings, f"user:{user.id}")
    if not cart["items"]:
        return redirect("/kundvagn")
    values = request.session.get("checkout_shipping") or {"name": user.name}
    return render(request, conn, settings, "checkout.html", cart=cart, values=values, errors={}, step="leverans")


@router.post("/kassa", response_class=HTMLResponse)
def checkout_submit(request: Request, name: str = Form(""), address: str = Form(""), zip: str = Form(""),
                    city: str = Form(""), payment: str = Form(""), personnummer: str = Form(""),
                    conn: Conn = Depends(get_conn, scope="function"), settings: Settings = Depends(get_settings)):
    user = login_required(request, conn)
    if isinstance(user, Response):
        return user
    cart = s.get_cart(conn, settings, f"user:{user.id}")
    shipping = {"name": name, "address": address, "zip": zip, "city": city}

    if settings.checkout_steps == 2:
        # Tvåstegsflöde: steg 1 sparar adressen, steg 2 (/kassa/betalning) lägger ordern.
        errors = {k: v for k, v in s.validate_checkout({**shipping, "payment": "kort"}).items()}
        if errors:
            return render(request, conn, settings, "checkout.html", status_code=422, cart=cart, values=shipping,
                          errors=errors, step="leverans")
        request.session["checkout_shipping"] = shipping
        return redirect("/kassa/betalning")

    return _place(request, conn, settings, user, cart, {**shipping, "payment": payment, "personnummer": personnummer},
                  step="leverans")


@router.get("/kassa/betalning", response_class=HTMLResponse)
def payment_page(request: Request, conn: Conn = Depends(get_conn, scope="function"), settings: Settings = Depends(get_settings)):
    user = login_required(request, conn)
    if isinstance(user, Response):
        return user
    shipping = request.session.get("checkout_shipping")
    if settings.checkout_steps != 2 or not shipping:
        return redirect("/kassa")
    cart = s.get_cart(conn, settings, f"user:{user.id}")
    return render(request, conn, settings, "checkout.html", cart=cart, values=shipping, errors={}, step="betalning")


@router.post("/kassa/betalning", response_class=HTMLResponse)
def payment_submit(request: Request, payment: str = Form(""), personnummer: str = Form(""),
                   conn: Conn = Depends(get_conn, scope="function"), settings: Settings = Depends(get_settings)):
    user = login_required(request, conn)
    if isinstance(user, Response):
        return user
    shipping = request.session.get("checkout_shipping")
    if not shipping:
        return redirect("/kassa")
    cart = s.get_cart(conn, settings, f"user:{user.id}")
    return _place(request, conn, settings, user, cart, {**shipping, "payment": payment, "personnummer": personnummer},
                  step="betalning")


def _place(request, conn, settings, user, cart, data, step):
    try:
        order_id = s.place_order(conn, settings, user, f"user:{user.id}", data)
    except ServiceError as exc:
        errors = getattr(exc, "errors", None) or {"form": exc.message}
        return render(request, conn, settings, "checkout.html", status_code=exc.status_code, cart=cart,
                      values=data, errors=errors, step=step)
    request.session.pop("checkout_shipping", None)
    flash(request, settings.texts["order_thanks"], "success")
    return redirect(f"/mina-ordrar/{order_id}")


# ------------------------------------------------------------------ ordrar

@router.get("/mina-ordrar", response_class=HTMLResponse)
def orders_page(request: Request, conn: Conn = Depends(get_conn, scope="function"), settings: Settings = Depends(get_settings)):
    user = login_required(request, conn)
    if isinstance(user, Response):
        return user
    return render(request, conn, settings, "orders.html", orders=s.list_orders(conn, user))


@router.get("/mina-ordrar/{order_id}", response_class=HTMLResponse)
def order_page(request: Request, order_id: int, conn: Conn = Depends(get_conn, scope="function"),
               settings: Settings = Depends(get_settings)):
    user = login_required(request, conn)
    if isinstance(user, Response):
        return user
    try:
        order = s.get_order(conn, settings, user, order_id, enforce_owner=True)
    except ServiceError:
        return render(request, conn, settings, "not_found.html", status_code=404)
    return render(request, conn, settings, "order.html", order=order)
