// TechRetail – lägg i kundvagn utan sidomladdning.
// Badgen läser antalet från /api/cart/summary efter att varan lagts till.
(function () {
  "use strict";

  function toast(message, isError) {
    var el = document.getElementById("toast");
    if (!el) return;
    el.textContent = message;
    el.className = "toast visible" + (isError ? " error" : "");
    clearTimeout(el._timer);
    el._timer = setTimeout(function () { el.className = "toast"; }, 4000);
  }

  function refreshBadge() {
    return fetch("/api/cart/summary", { credentials: "same-origin" })
      .then(function (r) { return r.ok ? r.json() : null; })
      .then(function (data) {
        if (!data) return;
        var badge = document.querySelector("[data-test='cart-badge']");
        if (badge) badge.textContent = String(data.item_count);
      });
  }

  function addToCart(productId, quantity, name, button) {
    if (button) button.disabled = true;
    return fetch("/api/cart/items", {
      method: "POST",
      credentials: "same-origin",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ product_id: Number(productId), quantity: Number(quantity) || 1 })
    })
      .then(function (r) {
        return r.json().then(function (body) { return { ok: r.ok, body: body }; });
      })
      .then(function (res) {
        if (!res.ok) {
          toast(res.body.detail || "Det gick inte att lägga till varan.", true);
          return;
        }
        var template = (window.TR_TEXTS && window.TR_TEXTS.added) || "{name} har lagts i kundvagnen.";
        toast(template.replace("{name}", name));
        return refreshBadge();
      })
      .catch(function () { toast("Nätverksfel. Försök igen.", true); })
      .finally(function () { if (button) button.disabled = false; });
  }

  document.addEventListener("click", function (event) {
    var button = event.target.closest(".js-add");
    if (!button) return;
    event.preventDefault();
    addToCart(button.dataset.productId, 1, button.dataset.productName, button);
  });

  document.addEventListener("submit", function (event) {
    var form = event.target.closest(".js-buy-form");
    if (!form) return;
    event.preventDefault();
    var qty = form.querySelector("[name='quantity']").value;
    addToCart(form.dataset.productId, qty, form.dataset.productName, form.querySelector("button[type='submit']"));
  });
})();
