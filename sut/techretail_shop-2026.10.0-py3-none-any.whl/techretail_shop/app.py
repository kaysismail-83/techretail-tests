"""Skapar FastAPI-appen: webbsidor, REST-API och testendpoints."""

from __future__ import annotations

import asyncio
import logging
import secrets
import sys
import time
from importlib import resources
from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles
from starlette.middleware.sessions import SessionMiddleware

from . import __version__
from .config import Settings, load_settings
from .db import Database, QueryStats, query_stats
from .services import ServiceError

DESCRIPTION = """
REST-API för TechRetail AB:s övningsbutik.

**Kom igång:** hämta en token med `POST /api/auth/token` och skicka den som
`Authorization: Bearer <token>`. Testkonton: `kund@example.com`, `kund2@example.com`,
`ny@example.com` (lösenord `Test1234!`).

Belopp anges i öre (`*_ore`) för att undvika avrundningsfel. Alla data är påhittade.
"""

TAGS = [
    {"name": "auth", "description": "Inloggning och token"},
    {"name": "produkter", "description": "Produktkatalog, sök och filter"},
    {"name": "kundvagn", "description": "Kundvagn och rabattkod"},
    {"name": "ordrar", "description": "Beställningar"},
    {"name": "test", "description": "Hjälpendpoints för testmiljön"},
]


def _configure_logging(settings: Settings) -> None:
    settings.log_dir.mkdir(parents=True, exist_ok=True)
    logger = logging.getLogger("techretail")
    logger.setLevel(logging.INFO)
    for handler in list(logger.handlers):
        logger.removeHandler(handler)
        handler.close()
    fmt = logging.Formatter("%(asctime)s %(levelname)s %(name)s %(message)s")
    file_handler = logging.FileHandler(settings.log_dir / "techretail.log", encoding="utf-8")
    file_handler.setFormatter(fmt)
    stream_handler = logging.StreamHandler(sys.stdout)
    stream_handler.setFormatter(fmt)
    logger.addHandler(file_handler)
    logger.addHandler(stream_handler)
    logger.propagate = False


def create_app(settings: Settings | None = None) -> FastAPI:
    settings = settings or load_settings()
    database = Database(settings.db_path, settings.db_latency_ms)
    database.initialize()
    _configure_logging(settings)

    app = FastAPI(
        title="TechRetail API",
        version=__version__,
        description=DESCRIPTION,
        openapi_tags=TAGS,
    )
    app.state.settings = settings
    app.state.db = database

    pool = asyncio.Semaphore(settings.db_pool) if settings.db_pool > 0 else None
    no_db = ("/static", "/health", "/docs", "/openapi.json", "/api/cart/summary")

    @app.middleware("http")
    async def db_pool(request: Request, call_next):
        """Begränsat antal samtidiga databasanslutningar. Övriga anrop väntar i kö."""
        if pool is None or request.url.path.startswith(no_db):
            return await call_next(request)
        try:
            await asyncio.wait_for(pool.acquire(), timeout=30)
        except TimeoutError:
            return JSONResponse(status_code=503, content={"detail": "Tjänsten är överbelastad. Försök igen."})
        try:
            return await call_next(request)
        finally:
            pool.release()

    @app.middleware("http")
    async def server_timing(request: Request, call_next):
        stats = QueryStats()
        token = query_stats.set(stats)
        start = time.perf_counter()
        try:
            response = await call_next(request)
        finally:
            query_stats.reset(token)
        total_ms = (time.perf_counter() - start) * 1000
        response.headers["Server-Timing"] = (
            f'db;desc="queries={stats.count}";dur={stats.seconds * 1000:.1f}, app;dur={total_ms:.1f}'
        )
        response.headers["X-Query-Count"] = str(stats.count)
        return response

    app.add_middleware(
        SessionMiddleware,
        secret_key=settings.secret_key,
        session_cookie="techretail_session",
        same_site="lax",
        https_only=False,
    )

    @app.exception_handler(ServiceError)
    async def service_error_handler(request: Request, exc: ServiceError):
        body = {"detail": exc.message}
        if getattr(exc, "errors", None):
            body["errors"] = exc.errors
        return JSONResponse(status_code=exc.status_code, content=body)

    @app.exception_handler(Exception)
    async def unhandled(request: Request, exc: Exception):
        logging.getLogger("techretail.error").exception("Oväntat fel på %s", request.url.path)
        return JSONResponse(status_code=500, content={"detail": "Internt serverfel."})

    from .api import router as api_router
    from .testing import router as test_router
    from .web import router as web_router

    app.include_router(api_router)
    if settings.test_endpoints:
        app.include_router(test_router)
    app.include_router(web_router)

    static_dir = Path(str(resources.files("techretail_shop") / "static"))
    app.mount("/static", StaticFiles(directory=static_dir), name="static")

    @app.get("/health", tags=["test"], summary="Hälsokontroll")
    def health():
        return {"status": "ok", "app": "techretail-shop", "version": __version__,
                "profile": settings.profile_name}

    return app


def anon_id() -> str:
    return secrets.token_hex(12)
