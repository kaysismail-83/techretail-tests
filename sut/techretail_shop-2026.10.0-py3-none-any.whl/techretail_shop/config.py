"""Inställningar, profiler och feature flags för techretail-shop.

En *profil* är en TOML-fil som bestämmer vilka flaggor som är påslagna,
vilka texter som visas och hur kassaflödet ser ut. Inbyggda
profiler finns i ``techretail_shop/profiles/``. En extern profil (till exempel
kursledarens tentavariant) anges med en sökväg.

Miljövariabler (alla valfria):

TECHRETAIL_PROFILE        profilnamn eller sökväg till .toml (standard: kurs)
TECHRETAIL_FLAGS          ersätter profilens flaggor: "all", "none", "alfa,echo"
                          eller ändrar dem: "+echo,-charlie"
TECHRETAIL_DB             sökväg till SQLite-filen
TECHRETAIL_LOG_DIR        katalog för loggfilen techretail.log
TECHRETAIL_DB_LATENCY_MS  simulerad nätverksfördröjning per databasfråga
TECHRETAIL_DB_POOL        antal samtidiga databasanslutningar (standard 8)
TECHRETAIL_TEST_ENDPOINTS 1/0 – slår på/av /test/reset (standard: 1)
TECHRETAIL_SECRET         nyckel för sessionskakan
"""

from __future__ import annotations

import os
import tomllib
from dataclasses import dataclass, field
from importlib import resources
from pathlib import Path

from .texts import DEFAULT_TEXTS

FLAGS: tuple[str, ...] = ("alfa", "bravo", "charlie", "delta", "echo", "foxtrot", "golf")

DEFAULT_PROFILE = "kurs"


def default_home() -> Path:
    return Path(os.environ.get("TECHRETAIL_HOME", Path.home() / ".techretail-shop"))


@dataclass(frozen=True)
class Settings:
    profile_name: str = DEFAULT_PROFILE
    profile_description: str = ""
    flags: frozenset[str] = frozenset()
    texts: dict[str, str] = field(default_factory=lambda: dict(DEFAULT_TEXTS))
    checkout_steps: int = 1
    summary_delay_ms: tuple[int, int] = (200, 1400)
    flaky_search_rate: float = 0.0
    unstable_sort: bool = False
    db_path: Path = field(default_factory=lambda: default_home() / "shop.db")
    log_dir: Path = field(default_factory=lambda: default_home() / "logs")
    db_latency_ms: float = 2.0
    db_pool: int = 8
    test_endpoints: bool = True
    secret_key: str = "techretail-ovningsmiljo-inte-for-produktion"

    def on(self, flag: str) -> bool:
        return flag.lower() in self.flags


class ProfileError(ValueError):
    pass


def builtin_profiles() -> list[str]:
    folder = resources.files("techretail_shop") / "profiles"
    return sorted(p.name.removesuffix(".toml") for p in folder.iterdir() if p.name.endswith(".toml"))


def read_profile(name_or_path: str) -> dict:
    candidate = Path(name_or_path).expanduser()
    if candidate.suffix == ".toml" and candidate.exists():
        return tomllib.loads(candidate.read_text(encoding="utf-8"))
    resource = resources.files("techretail_shop") / "profiles" / f"{name_or_path}.toml"
    if resource.is_file():
        return tomllib.loads(resource.read_text(encoding="utf-8"))
    raise ProfileError(
        f"Hittar ingen profil som heter '{name_or_path}'. "
        f"Inbyggda profiler: {', '.join(builtin_profiles())}. "
        "En egen profil anges som sökväg till en .toml-fil."
    )


def parse_flags(spec: str | None, base: frozenset[str]) -> frozenset[str]:
    if spec is None or spec.strip() == "":
        return base
    spec = spec.strip()
    if spec.lower() == "all":
        return frozenset(FLAGS)
    if spec.lower() == "none":
        return frozenset()
    parts = [p.strip().lower() for p in spec.split(",") if p.strip()]
    for p in parts:
        if p.lstrip("+-") not in FLAGS:
            raise ProfileError(f"Okänd flagga '{p}'.")
    if all(p[0] in "+-" for p in parts):
        result = set(base)
        for p in parts:
            (result.add if p[0] == "+" else result.discard)(p[1:])
        return frozenset(result)
    return frozenset(p.lstrip("+") for p in parts)


def _bool_env(name: str, default: bool) -> bool:
    value = os.environ.get(name)
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "ja", "yes", "on"}


def load_settings(profile: str | None = None, flags: str | None = None, **overrides) -> Settings:
    """Bygg Settings från profil + miljövariabler + uttryckliga överskrivningar."""
    profile_name = profile or os.environ.get("TECHRETAIL_PROFILE") or DEFAULT_PROFILE
    data = read_profile(profile_name)

    base_flags = parse_flags(",".join(data.get("flags", [])) or "none", frozenset())
    flag_spec = flags if flags is not None else os.environ.get("TECHRETAIL_FLAGS")
    active = parse_flags(flag_spec, base_flags)

    texts = dict(DEFAULT_TEXTS)
    unknown = set(data.get("texts", {})) - set(DEFAULT_TEXTS)
    if unknown:
        raise ProfileError(f"Okända textnycklar i profilen: {', '.join(sorted(unknown))}")
    texts.update(data.get("texts", {}))

    echo = data.get("echo", {})
    flow = data.get("flow", {})
    l7 = data.get("l7", {})
    home = default_home()

    kwargs = dict(
        profile_name=data.get("name", profile_name),
        profile_description=data.get("description", ""),
        flags=active,
        texts=texts,
        checkout_steps=int(flow.get("checkout_steps", 1)),
        summary_delay_ms=tuple(echo.get("delay_ms", (200, 1400))),
        flaky_search_rate=float(l7.get("flaky_search_rate", 0.0)),
        unstable_sort=bool(l7.get("unstable_sort", False)),
        db_path=Path(os.environ.get("TECHRETAIL_DB", home / "shop.db")),
        log_dir=Path(os.environ.get("TECHRETAIL_LOG_DIR", home / "logs")),
        db_latency_ms=float(os.environ.get("TECHRETAIL_DB_LATENCY_MS", data.get("db_latency_ms", 2.0))),
        db_pool=int(os.environ.get("TECHRETAIL_DB_POOL", data.get("db_pool", 8))),
        test_endpoints=_bool_env("TECHRETAIL_TEST_ENDPOINTS", True),
        secret_key=os.environ.get("TECHRETAIL_SECRET", Settings.secret_key),
    )
    kwargs.update(overrides)
    return Settings(**kwargs)


def describe(settings: Settings) -> str:
    lines = [
        f"Profil:            {settings.profile_name}  {settings.profile_description}",
        f"Aktiva flaggor:    {', '.join(sorted(settings.flags)) or 'inga'}",
        f"Kassa, antal steg: {settings.checkout_steps}",
        f"echo, fördröjning: {settings.summary_delay_ms[0]}–{settings.summary_delay_ms[1]} ms",
        f"L7 instabil sök:   {settings.flaky_search_rate:.0%}, instabil sortering: {settings.unstable_sort}",
        f"Databas:           {settings.db_path}",
        f"Loggfil:           {settings.log_dir / 'techretail.log'}",
        f"DB-latens/fråga:   {settings.db_latency_ms} ms, pool: {settings.db_pool}",
        f"/test/reset:       {'på' if settings.test_endpoints else 'av'}",
    ]
    return "\n".join(lines)
