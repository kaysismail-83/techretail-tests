"""Gemensamma FastAPI-beroenden: databasanslutning, inloggad användare, kundvagnsnyckel."""

from __future__ import annotations

import secrets
from collections.abc import Iterator

from fastapi import Depends, Request

from .config import Settings
from .db import Conn
from .services import ServiceError, User, get_user, user_for_token


def get_settings(request: Request) -> Settings:
    return request.app.state.settings


def get_conn(request: Request) -> Iterator[Conn]:
    """Används alltid som Depends(get_conn, scope="function").

    Då körs commit innan svaret skickas. Utan scope körs koden efter yield först när
    svaret redan har gått iväg, och ett anrop direkt efteråt kan se gamla data.
    """
    conn = request.app.state.db.connect()
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def ensure_anon(request: Request) -> str:
    anon = request.session.get("anon")
    if not anon:
        anon = secrets.token_hex(12)
        request.session["anon"] = anon
    return anon


def optional_user(request: Request, conn: Conn = Depends(get_conn, scope="function")) -> User | None:
    header = request.headers.get("authorization", "")
    if header.lower().startswith("bearer "):
        user = user_for_token(conn, header[7:].strip())
        if user is None:
            raise ServiceError("Ogiltig eller utgången token.", 401)
        return user
    user_id = request.session.get("user_id")
    if user_id:
        return get_user(conn, user_id)
    return None


def require_user(user: User | None = Depends(optional_user)) -> User:
    if user is None:
        raise ServiceError("Du måste logga in. Skicka 'Authorization: Bearer <token>'.", 401)
    return user


def cart_key(request: Request, user: User | None = Depends(optional_user)) -> str:
    """Kundvagn för inloggad användare, annars för webbläsarsessionen."""
    if user is not None:
        return f"user:{user.id}"
    anon = request.session.get("anon")
    if not anon:
        raise ServiceError("Du måste logga in. Skicka 'Authorization: Bearer <token>'.", 401)
    return f"anon:{anon}"
