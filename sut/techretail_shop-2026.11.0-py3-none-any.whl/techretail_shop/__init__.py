"""TechRetail – övningsbutik för kursen Testautomation och AI inom IT-test."""

__version__ = "2026.11.0"
