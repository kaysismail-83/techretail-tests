"""REST-API under /api. Dokumentation: /docs och /openapi.json."""

from __future__ import annotations

import asyncio
from typing import Literal

from fastapi import APIRouter, Depends, Query, Request
from pydantic import BaseModel, Field

from . import services as s
from .config import Settings
from .db import Conn
from .deps import cart_key, get_conn, get_settings, require_user
from .services import User

router = APIRouter(prefix="/api")


# ------------------------------------------------------------------ modeller

class TokenRequest(BaseModel):
    email: str = Field(examples=["kund@example.com"])
    password: str = Field(examples=["Test1234!"])


class TokenResponse(BaseModel):
    access_token: str
    token_type: Literal["bearer"] = "bearer"
    expires_in: int


class UserOut(BaseModel):
    id: int
    email: str
    name: str


class Category(BaseModel):
    slug: str
    name: str


class Product(BaseModel):
    id: int
    sku: str
    name: str
    description: str
    price_ore: int
    price: float
    category: str
    category_name: str
    stock: int
    in_stock: bool
    image: str
    rating: float | None
    review_count: int


class ProductList(BaseModel):
    count: int
    items: list[Product]


class CartItemIn(BaseModel):
    product_id: int
    quantity: int = Field(default=1, ge=1, le=99)


class QuantityIn(BaseModel):
    quantity: int = Field(ge=0, le=99)


class DiscountIn(BaseModel):
    code: str = Field(examples=["TECH10"])


class CartItem(BaseModel):
    product_id: int
    name: str
    quantity: int
    unit_price_ore: int
    line_total_ore: int


class Cart(BaseModel):
    items: list[CartItem]
    item_count: int
    discount_code: str | None
    discount_percent: int
    subtotal_ore: int
    discount_ore: int
    shipping_ore: int
    total_ore: int
    vat_ore: int


class CartSummary(BaseModel):
    item_count: int


class OrderIn(BaseModel):
    name: str = Field(examples=["Kim Kund"])
    address: str = Field(examples=["Testgatan 1"])
    zip: str = Field(examples=["111 22"])
    city: str = Field(examples=["Exempelstad"])
    payment: Literal["kort", "faktura", "delbetalning"] = "kort"
    personnummer: str | None = Field(default=None, description="Krävs bara vid delbetalning.")


class OrderLine(BaseModel):
    product_id: int
    name: str
    unit_price_ore: int
    quantity: int


class Order(BaseModel):
    id: int
    user_id: int
    created_at: str
    status: str
    name: str
    address: str
    zip: str
    city: str
    payment: str
    discount_code: str | None
    subtotal_ore: int
    discount_ore: int
    shipping_ore: int
    total_ore: int
    lines: list[OrderLine]


class OrderCreated(BaseModel):
    id: int
    total_ore: int


# ------------------------------------------------------------------ auth

@router.post("/auth/token", response_model=TokenResponse, tags=["auth"], summary="Logga in och få en token")
def create_token(body: TokenRequest, conn: Conn = Depends(get_conn)):
    user = s.authenticate(conn, body.email, body.password)
    from .security import TOKEN_TTL_SECONDS
    return TokenResponse(access_token=s.issue_token(conn, user), expires_in=TOKEN_TTL_SECONDS)


@router.get("/me", response_model=UserOut, tags=["auth"], summary="Inloggad användare")
def me(user: User = Depends(require_user)):
    return UserOut(id=user.id, email=user.email, name=user.name)


# ------------------------------------------------------------------ produkter

@router.get("/categories", response_model=list[Category], tags=["produkter"], summary="Kategorier")
def categories(conn: Conn = Depends(get_conn)):
    return s.list_categories(conn)


@router.get("/products", response_model=ProductList, tags=["produkter"], summary="Sök och filtrera produkter")
def products(
    q: str | None = Query(default=None, description="Fritext i namn, beskrivning eller artikelnummer"),
    category: str | None = Query(default=None, description="Kategorins slug, t.ex. verktyg"),
    min_price: float | None = Query(default=None, ge=0, description="Lägsta pris i kronor"),
    max_price: float | None = Query(default=None, ge=0, description="Högsta pris i kronor"),
    sort: Literal["relevans", "pris-stigande", "pris-fallande", "namn"] = "relevans",
    limit: int = Query(default=50, ge=1, le=100),
    offset: int = Query(default=0, ge=0),
    conn: Conn = Depends(get_conn),
    settings: Settings = Depends(get_settings),
):
    items = s.search_products(conn, settings, q=q, category=category, min_price=min_price,
                              max_price=max_price, sort=sort, limit=limit, offset=offset)
    return {"count": len(items), "items": items}


@router.get("/products/{product_id}", response_model=Product, tags=["produkter"], summary="En produkt")
def product(product_id: int, conn: Conn = Depends(get_conn)):
    return s.get_product(conn, product_id)


# ------------------------------------------------------------------ kundvagn

@router.get("/cart", response_model=Cart, tags=["kundvagn"], summary="Visa kundvagnen")
def get_cart(key: str = Depends(cart_key), conn: Conn = Depends(get_conn), settings: Settings = Depends(get_settings)):
    return s.get_cart(conn, settings, key)


async def _summary_wait(request: Request) -> None:
    delay = s.cart_summary_delay(request.app.state.settings)
    if delay:
        await asyncio.sleep(delay)


@router.get("/cart/summary", response_model=CartSummary, tags=["kundvagn"],
            summary="Antal varor (används av kundvagnsbadgen)")
def cart_summary(_: None = Depends(_summary_wait), key: str = Depends(cart_key), conn: Conn = Depends(get_conn)):
    return {"item_count": s.item_count(conn, key)}


@router.post("/cart/items", response_model=Cart, status_code=201, tags=["kundvagn"], summary="Lägg till vara")
def add_item(body: CartItemIn, key: str = Depends(cart_key), conn: Conn = Depends(get_conn),
             settings: Settings = Depends(get_settings)):
    s.add_to_cart(conn, key, body.product_id, body.quantity)
    return s.get_cart(conn, settings, key)


@router.patch("/cart/items/{product_id}", response_model=Cart, tags=["kundvagn"], summary="Ändra antal (0 tar bort)")
def update_item(product_id: int, body: QuantityIn, key: str = Depends(cart_key), conn: Conn = Depends(get_conn),
                settings: Settings = Depends(get_settings)):
    s.set_quantity(conn, key, product_id, body.quantity)
    return s.get_cart(conn, settings, key)


@router.delete("/cart/items/{product_id}", response_model=Cart, tags=["kundvagn"], summary="Ta bort vara")
def delete_item(product_id: int, key: str = Depends(cart_key), conn: Conn = Depends(get_conn),
                settings: Settings = Depends(get_settings)):
    s.remove_from_cart(conn, key, product_id)
    return s.get_cart(conn, settings, key)


@router.delete("/cart", response_model=Cart, tags=["kundvagn"], summary="Töm kundvagnen")
def empty_cart(key: str = Depends(cart_key), conn: Conn = Depends(get_conn), settings: Settings = Depends(get_settings)):
    s.clear_cart(conn, key)
    return s.get_cart(conn, settings, key)


@router.post("/cart/discount", response_model=Cart, tags=["kundvagn"], summary="Använd rabattkod")
def add_discount(body: DiscountIn, key: str = Depends(cart_key), conn: Conn = Depends(get_conn),
                 settings: Settings = Depends(get_settings)):
    s.apply_discount_code(conn, key, body.code)
    return s.get_cart(conn, settings, key)


@router.delete("/cart/discount", response_model=Cart, tags=["kundvagn"], summary="Ta bort rabattkod")
def delete_discount(key: str = Depends(cart_key), conn: Conn = Depends(get_conn),
                    settings: Settings = Depends(get_settings)):
    s.remove_discount_code(conn, key)
    return s.get_cart(conn, settings, key)


# ------------------------------------------------------------------ ordrar

@router.post("/orders", response_model=OrderCreated, status_code=201, tags=["ordrar"],
             summary="Lägg order av kundvagnens innehåll")
def create_order(body: OrderIn, user: User = Depends(require_user), conn: Conn = Depends(get_conn),
                 settings: Settings = Depends(get_settings)):
    order_id = s.place_order(conn, settings, user, f"user:{user.id}", body.model_dump())
    order = s.get_order(conn, settings, user, order_id, enforce_owner=True)
    return {"id": order_id, "total_ore": order["total_ore"]}


@router.get("/orders", response_model=list[Order], tags=["ordrar"], summary="Mina ordrar")
def my_orders(user: User = Depends(require_user), conn: Conn = Depends(get_conn)):
    return s.list_orders(conn, user)


@router.get("/orders/{order_id}", response_model=Order, tags=["ordrar"], summary="En order")
def one_order(order_id: int, user: User = Depends(require_user), conn: Conn = Depends(get_conn),
              settings: Settings = Depends(get_settings)):
    return s.get_order(conn, settings, user, order_id)
