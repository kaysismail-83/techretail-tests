"""Affärslogik: användare, produkter, kundvagn och ordrar."""

from __future__ import annotations

import logging
import random
import re
import time
from dataclasses import dataclass
from datetime import date

from .config import Settings
from .db import Conn
from .pricing import order_totals
from .security import TOKEN_TTL_SECONDS, new_token, verify_password

checkout_log = logging.getLogger("techretail.checkout")


class ServiceError(Exception):
    status_code = 400

    def __init__(self, message: str, status_code: int | None = None):
        super().__init__(message)
        self.message = message
        if status_code:
            self.status_code = status_code


@dataclass
class User:
    id: int
    email: str
    name: str


# ---------------------------------------------------------------- användare

def authenticate(conn: Conn, email: str, password: str) -> User:
    row = conn.one("SELECT * FROM users WHERE email = ?", (email.strip().lower(),))
    if row is None or not verify_password(password, row["password_hash"]):
        raise ServiceError("Fel e-post eller lösenord.", 401)
    if row["locked"]:
        raise ServiceError("Kontot är låst.", 423)
    return User(row["id"], row["email"], row["name"])


def issue_token(conn: Conn, user: User) -> str:
    token = new_token()
    conn.run("INSERT INTO tokens (token, user_id, expires_at) VALUES (?, ?, ?)",
             (token, user.id, time.time() + TOKEN_TTL_SECONDS))
    return token


def user_for_token(conn: Conn, token: str) -> User | None:
    row = conn.one(
        "SELECT u.id, u.email, u.name FROM tokens t JOIN users u ON u.id = t.user_id "
        "WHERE t.token = ? AND t.expires_at > ?", (token, time.time()))
    return User(row["id"], row["email"], row["name"]) if row else None


def get_user(conn: Conn, user_id: int) -> User | None:
    row = conn.one("SELECT id, email, name FROM users WHERE id = ?", (user_id,))
    return User(row["id"], row["email"], row["name"]) if row else None


# ---------------------------------------------------------------- produkter

SORTS = {
    "relevans": "p.id ASC",
    "pris-stigande": "p.price_ore ASC, p.id ASC",
    "pris-fallande": "p.price_ore DESC, p.id ASC",
    "namn": "p.name ASC",
}


def _product_dict(row, category_name, category_slug, avg, count) -> dict:
    return {
        "id": row["id"],
        "sku": row["sku"],
        "name": row["name"],
        "description": row["description"],
        "price_ore": row["price_ore"],
        "price": row["price_ore"] / 100,
        "category": category_slug,
        "category_name": category_name,
        "stock": row["stock"],
        "in_stock": row["stock"] > 0,
        "image": row["image"],
        "rating": round(avg, 1) if avg else None,
        "review_count": count or 0,
    }


def list_categories(conn: Conn) -> list[dict]:
    return [dict(r) for r in conn.all("SELECT slug, name FROM categories ORDER BY id")]


def search_products(conn: Conn, settings: Settings, *, q: str | None = None, category: str | None = None,
                    min_price: float | None = None, max_price: float | None = None,
                    sort: str = "relevans", limit: int = 50, offset: int = 0) -> list[dict]:
    if settings.flaky_search_rate and random.random() < settings.flaky_search_rate:
        # L7-variant: sporadiskt fel som efterliknar en överbelastad söktjänst.
        raise ServiceError("Söktjänsten är tillfälligt otillgänglig. Försök igen.", 503)

    where, params = [], []
    if q:
        where.append("(p.name LIKE ? OR p.description LIKE ? OR p.sku LIKE ?)")
        like = f"%{q.strip()}%"
        params += [like, like, like]
    if category:
        if settings.on("charlie"):
            where.append(f"c.slug = '{category}'")
        else:
            where.append("c.slug = ?")
            params.append(category)
    if min_price is not None:
        where.append("p.price_ore >= ?")
        params.append(int(round(min_price * 100)))
    if max_price is not None:
        where.append("p.price_ore <= ?")
        params.append(int(round(max_price * 100)))
    where_sql = ("WHERE " + " AND ".join(where)) if where else ""
    order_sql = SORTS.get(sort, SORTS["relevans"])
    limit = max(1, min(int(limit), 100))
    offset = max(0, int(offset))

    if settings.on("golf"):
        rows = conn.all(
            f"SELECT p.* FROM products p JOIN categories c ON c.id = p.category_id {where_sql} "
            f"ORDER BY {order_sql} LIMIT ? OFFSET ?", (*params, limit, offset))
        result = []
        for row in rows:
            cat = conn.one("SELECT name, slug FROM categories WHERE id = ?", (row["category_id"],))
            rev = conn.one("SELECT AVG(rating) AS avg, COUNT(*) AS n FROM reviews WHERE product_id = ?", (row["id"],))
            result.append(_product_dict(row, cat["name"], cat["slug"], rev["avg"], rev["n"]))
    else:
        rows = conn.all(
            "SELECT p.*, c.name AS category_name, c.slug AS category_slug, r.avg AS avg, r.n AS n "
            "FROM products p JOIN categories c ON c.id = p.category_id "
            "LEFT JOIN (SELECT product_id, AVG(rating) AS avg, COUNT(*) AS n FROM reviews GROUP BY product_id) r "
            f"ON r.product_id = p.id {where_sql} ORDER BY {order_sql} LIMIT ? OFFSET ?",
            (*params, limit, offset))
        result = [_product_dict(r, r["category_name"], r["category_slug"], r["avg"], r["n"]) for r in rows]

    if settings.unstable_sort and sort == "relevans":
        # L7-variant: ordningen är inte deterministisk.
        random.shuffle(result)
    return result


def get_product(conn: Conn, product_id: int) -> dict:
    row = conn.one(
        "SELECT p.*, c.name AS category_name, c.slug AS category_slug, "
        "(SELECT AVG(rating) FROM reviews WHERE product_id = p.id) AS avg, "
        "(SELECT COUNT(*) FROM reviews WHERE product_id = p.id) AS n "
        "FROM products p JOIN categories c ON c.id = p.category_id WHERE p.id = ?", (product_id,))
    if row is None:
        raise ServiceError("Produkten finns inte.", 404)
    return _product_dict(row, row["category_name"], row["category_slug"], row["avg"], row["n"])


# ---------------------------------------------------------------- kundvagn

def _ensure_cart(conn: Conn, cart_key: str) -> None:
    conn.run("INSERT OR IGNORE INTO carts (cart_key) VALUES (?)", (cart_key,))


def add_to_cart(conn: Conn, cart_key: str, product_id: int, quantity: int = 1) -> None:
    if quantity < 1 or quantity > 99:
        raise ServiceError("Antal måste vara mellan 1 och 99.", 422)
    product = get_product(conn, product_id)
    _ensure_cart(conn, cart_key)
    row = conn.one("SELECT quantity FROM cart_items WHERE cart_key = ? AND product_id = ?", (cart_key, product_id))
    new_qty = quantity + (row["quantity"] if row else 0)
    if new_qty > product["stock"]:
        if product["stock"] == 0:
            raise ServiceError(f"{product['name']} är slut i lager.", 409)
        raise ServiceError(f"Det finns bara {product['stock']} st av {product['name']} i lager.", 409)
    conn.run("INSERT INTO cart_items (cart_key, product_id, quantity) VALUES (?, ?, ?) "
             "ON CONFLICT(cart_key, product_id) DO UPDATE SET quantity = excluded.quantity",
             (cart_key, product_id, new_qty))


def set_quantity(conn: Conn, cart_key: str, product_id: int, quantity: int) -> None:
    if quantity == 0:
        remove_from_cart(conn, cart_key, product_id)
        return
    if quantity < 0 or quantity > 99:
        raise ServiceError("Antal måste vara mellan 0 och 99.", 422)
    product = get_product(conn, product_id)
    if quantity > product["stock"]:
        raise ServiceError(f"Det finns bara {product['stock']} st av {product['name']} i lager.", 409)
    row = conn.one("SELECT 1 FROM cart_items WHERE cart_key = ? AND product_id = ?", (cart_key, product_id))
    if row is None:
        raise ServiceError("Produkten finns inte i kundvagnen.", 404)
    conn.run("UPDATE cart_items SET quantity = ? WHERE cart_key = ? AND product_id = ?", (quantity, cart_key, product_id))


def remove_from_cart(conn: Conn, cart_key: str, product_id: int) -> None:
    conn.run("DELETE FROM cart_items WHERE cart_key = ? AND product_id = ?", (cart_key, product_id))


def clear_cart(conn: Conn, cart_key: str) -> None:
    conn.run("DELETE FROM cart_items WHERE cart_key = ?", (cart_key,))
    conn.run("UPDATE carts SET discount_code = NULL WHERE cart_key = ?", (cart_key,))


def apply_discount_code(conn: Conn, cart_key: str, code: str) -> dict:
    row = conn.one("SELECT * FROM discount_codes WHERE code = ? AND active = 1", (code.strip().upper(),))
    if row is None:
        raise ServiceError("Rabattkoden är ogiltig eller har gått ut.", 422)
    _ensure_cart(conn, cart_key)
    conn.run("UPDATE carts SET discount_code = ? WHERE cart_key = ?", (row["code"], cart_key))
    return {"code": row["code"], "percent": row["percent"]}


def remove_discount_code(conn: Conn, cart_key: str) -> None:
    conn.run("UPDATE carts SET discount_code = NULL WHERE cart_key = ?", (cart_key,))


def merge_carts(conn: Conn, from_key: str, to_key: str) -> None:
    items = conn.all("SELECT product_id, quantity FROM cart_items WHERE cart_key = ?", (from_key,))
    for item in items:
        try:
            add_to_cart(conn, to_key, item["product_id"], item["quantity"])
        except ServiceError:
            pass
    conn.run("DELETE FROM carts WHERE cart_key = ?", (from_key,))


def item_count(conn: Conn, cart_key: str) -> int:
    row = conn.one("SELECT COALESCE(SUM(quantity), 0) AS n FROM cart_items WHERE cart_key = ?", (cart_key,))
    return int(row["n"])


def get_cart(conn: Conn, settings: Settings, cart_key: str) -> dict:
    rows = conn.all(
        "SELECT ci.product_id, ci.quantity, p.name, p.price_ore, p.stock FROM cart_items ci "
        "JOIN products p ON p.id = ci.product_id WHERE ci.cart_key = ? ORDER BY p.name", (cart_key,))
    cart = conn.one("SELECT c.discount_code, d.percent FROM carts c LEFT JOIN discount_codes d "
                    "ON d.code = c.discount_code WHERE c.cart_key = ?", (cart_key,))
    code = cart["discount_code"] if cart else None
    percent = cart["percent"] if cart and cart["percent"] is not None else 0
    items = [{
        "product_id": r["product_id"], "name": r["name"], "quantity": r["quantity"],
        "unit_price_ore": r["price_ore"], "line_total_ore": r["price_ore"] * r["quantity"],
    } for r in rows]
    subtotal = sum(i["line_total_ore"] for i in items)
    totals = order_totals(subtotal, percent, alt_rounding=settings.on("delta"))
    return {
        "items": items,
        "item_count": sum(i["quantity"] for i in items),
        "discount_code": code,
        "discount_percent": percent,
        "subtotal_ore": totals["subtotal"],
        "discount_ore": totals["discount"],
        "shipping_ore": totals["shipping"],
        "total_ore": totals["total"],
        "vat_ore": totals["vat"],
    }


def cart_summary_delay(settings: Settings) -> float:
    """Svarstid för sammanfattningen som badgen läser, i sekunder."""
    if not settings.on("echo"):
        return 0.0
    low, high = settings.summary_delay_ms
    return random.uniform(low, high) / 1000


# ---------------------------------------------------------------- ordrar

PNR_RE = re.compile(r"^(\d{2})?(\d{2})(\d{2})(\d{2})[-+]?(\d{4})$")
ZIP_RE = re.compile(r"^\d{3} ?\d{2}$")


def valid_personnummer(value: str) -> bool:
    m = PNR_RE.match(value.strip())
    if not m:
        return False
    digits = "".join(g for g in m.groups()[1:] if g)
    total = 0
    for i, ch in enumerate(digits):
        d = int(ch) * (2 if i % 2 == 0 else 1)
        total += d - 9 if d > 9 else d
    return total % 10 == 0


def validate_checkout(data: dict) -> dict[str, str]:
    errors = {}
    for key, label in (("name", "Namn"), ("address", "Gatuadress"), ("zip", "Postnummer"), ("city", "Ort")):
        if not str(data.get(key) or "").strip():
            errors[key] = f"{label} måste fyllas i."
    if data.get("zip") and not ZIP_RE.match(str(data["zip"]).strip()):
        errors["zip"] = "Postnummer ska ha fem siffror, till exempel 123 45."
    if data.get("payment") not in {"kort", "faktura", "delbetalning"}:
        errors["payment"] = "Välj betalsätt."
    if data.get("payment") == "delbetalning":
        pnr = str(data.get("personnummer") or "").strip()
        if not pnr:
            errors["personnummer"] = "Personnummer krävs för delbetalning."
        elif not valid_personnummer(pnr):
            errors["personnummer"] = "Personnumret är ogiltigt."
    return errors


def place_order(conn: Conn, settings: Settings, user: User, cart_key: str, data: dict) -> int:
    errors = validate_checkout(data)
    if errors:
        err = ServiceError("Kontrollera uppgifterna.", 422)
        err.errors = errors  # type: ignore[attr-defined]
        raise err
    cart = get_cart(conn, settings, cart_key)
    if not cart["items"]:
        raise ServiceError("Kundvagnen är tom.", 409)
    for item in cart["items"]:
        stock = conn.one("SELECT stock FROM products WHERE id = ?", (item["product_id"],))["stock"]
        if item["quantity"] > stock:
            raise ServiceError(f"Det finns bara {stock} st av {item['name']} i lager.", 409)
    cur = conn.run(
        "INSERT INTO orders (user_id, created_at, status, name, address, zip, city, payment, discount_code,"
        " subtotal_ore, discount_ore, shipping_ore, total_ore) VALUES (?, ?, 'Behandlas', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        (user.id, date.today().isoformat(), data["name"].strip(), data["address"].strip(),
         data["zip"].strip(), data["city"].strip(), data["payment"], cart["discount_code"],
         cart["subtotal_ore"], cart["discount_ore"], cart["shipping_ore"], cart["total_ore"]))
    order_id = cur.lastrowid
    for item in cart["items"]:
        conn.run("INSERT INTO order_lines (order_id, product_id, name, unit_price_ore, quantity) VALUES (?, ?, ?, ?, ?)",
                 (order_id, item["product_id"], item["name"], item["unit_price_ore"], item["quantity"]))
        conn.run("UPDATE products SET stock = stock - ? WHERE id = ?", (item["quantity"], item["product_id"]))
    clear_cart(conn, cart_key)

    if settings.on("foxtrot"):
        checkout_log.info("Order %s skapad: user=%s belopp=%s betalning=%s personnummer=%s",
                          order_id, user.email, cart["total_ore"], data["payment"], data.get("personnummer") or "-")
    else:
        checkout_log.info("Order %s skapad: user_id=%s belopp=%s betalning=%s personnummer_angivet=%s",
                          order_id, user.id, cart["total_ore"], data["payment"], bool(data.get("personnummer")))
    return order_id


def _order_dict(conn: Conn, row) -> dict:
    lines = conn.all("SELECT product_id, name, unit_price_ore, quantity FROM order_lines WHERE order_id = ?", (row["id"],))
    return {
        "id": row["id"], "user_id": row["user_id"], "created_at": row["created_at"], "status": row["status"],
        "name": row["name"], "address": row["address"], "zip": row["zip"], "city": row["city"],
        "payment": row["payment"], "discount_code": row["discount_code"],
        "subtotal_ore": row["subtotal_ore"], "discount_ore": row["discount_ore"],
        "shipping_ore": row["shipping_ore"], "total_ore": row["total_ore"],
        "discount_percent": round(row["discount_ore"] * 100 / row["subtotal_ore"]) if row["subtotal_ore"] else 0,
        "vat_ore": (row["total_ore"] * 20 + 50) // 100,
        "lines": [dict(line) for line in lines],
    }


def list_orders(conn: Conn, user: User) -> list[dict]:
    rows = conn.all("SELECT * FROM orders WHERE user_id = ? ORDER BY id DESC", (user.id,))
    return [_order_dict(conn, r) for r in rows]


def get_order(conn: Conn, settings: Settings, user: User, order_id: int, *, enforce_owner: bool | None = None) -> dict:
    row = conn.one("SELECT * FROM orders WHERE id = ?", (order_id,))
    if enforce_owner is None:
        enforce_owner = not settings.on("alfa")
    if row is None or (enforce_owner and row["user_id"] != user.id):
        raise ServiceError("Ordern finns inte.", 404)
    return _order_dict(conn, row)
