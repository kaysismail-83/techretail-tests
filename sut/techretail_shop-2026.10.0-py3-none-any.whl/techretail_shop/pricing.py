"""Prisberäkning i öre (heltal). Rabatt avrundas till närmaste öre (halvt uppåt).

Regler:
- Rabatt i procent på delsumman.
- Frakt 49 kr om beloppet efter rabatt är under 500 kr, annars fri frakt.
- Tom kundvagn har ingen frakt.
- Priser är inklusive 25 % moms. Momsen är 20 % av totalbeloppet.
"""

from __future__ import annotations

SHIPPING_ORE = 4900
FREE_SHIPPING_FROM_ORE = 50000


def discount_ore(subtotal_ore: int, percent: int, *, alt_rounding: bool = False) -> int:
    if not 0 <= percent <= 100:
        raise ValueError("Rabatten måste vara mellan 0 och 100 procent.")
    if alt_rounding:
        return int(subtotal_ore // 100 * percent / 100) * 100
    return (subtotal_ore * percent + 50) // 100


def shipping_ore(amount_after_discount_ore: int, has_items: bool = True) -> int:
    if not has_items:
        return 0
    return 0 if amount_after_discount_ore >= FREE_SHIPPING_FROM_ORE else SHIPPING_ORE


def order_totals(subtotal: int, percent: int, *, alt_rounding: bool = False) -> dict[str, int]:
    discount = discount_ore(subtotal, percent, alt_rounding=alt_rounding)
    after = subtotal - discount
    shipping = shipping_ore(after, has_items=subtotal > 0)
    total = after + shipping
    return {
        "subtotal": subtotal,
        "discount": discount,
        "shipping": shipping,
        "total": total,
        "vat": (total * 20 + 50) // 100,
    }


def format_sek(ore: int) -> str:
    """19990 -> '199,90 kr', 149900 -> '1 499,00 kr' (vanligt mellanslag som tusentalsavgränsare)."""
    sign = "-" if ore < 0 else ""
    kronor, rest = divmod(abs(ore), 100)
    return f"{sign}{kronor:,}".replace(",", " ") + f",{rest:02d} kr"
