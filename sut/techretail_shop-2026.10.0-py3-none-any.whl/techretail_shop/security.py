"""Lösenordshashning och API-token. Enkel men korrekt nog för en övningsmiljö."""

from __future__ import annotations

import hashlib
import hmac
import secrets

ITERATIONS = 60_000
TOKEN_TTL_SECONDS = 8 * 60 * 60


def hash_password(password: str, salt: str | None = None) -> str:
    salt = salt or secrets.token_hex(8)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), salt.encode(), ITERATIONS).hex()
    return f"pbkdf2${salt}${digest}"


def verify_password(password: str, stored: str) -> bool:
    try:
        _, salt, digest = stored.split("$")
    except ValueError:
        return False
    candidate = hash_password(password, salt).split("$")[2]
    return hmac.compare_digest(candidate, digest)


def new_token() -> str:
    return secrets.token_urlsafe(24)
