"""Kommandoradsverktyget `techretail-shop`."""

from __future__ import annotations

import argparse
import os
import sys

from . import __version__
from .config import ProfileError, builtin_profiles, describe, load_settings
from .db import Database


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="techretail-shop",
        description="Startar TechRetail AB:s övningsbutik (system under test).",
    )
    parser.add_argument("--host", default=os.environ.get("TECHRETAIL_HOST", "127.0.0.1"),
                        help="Adress att lyssna på (standard 127.0.0.1)")
    parser.add_argument("--port", type=int, default=int(os.environ.get("TECHRETAIL_PORT", "8000")),
                        help="Port (standard 8000)")
    parser.add_argument("--profile", help=f"Profilnamn ({', '.join(builtin_profiles())}) eller sökväg till .toml")
    parser.add_argument("--flags", help="Kursledarens inställningar (beskrivs i kursledarens material)")
    parser.add_argument("--reset", action="store_true", help="Återställ databasen till seedad data och avsluta")
    parser.add_argument("--show-config", action="store_true", help="Visa aktiv konfiguration och avsluta")
    parser.add_argument("--version", action="version", version=f"techretail-shop {__version__}")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        settings = load_settings(profile=args.profile, flags=args.flags)
    except ProfileError as exc:
        print(f"Fel: {exc}", file=sys.stderr)
        return 2

    if args.show_config:
        print(describe(settings))
        return 0

    if args.reset:
        Database(settings.db_path).initialize(force_reset=True)
        print(f"Databasen är återställd: {settings.db_path}")
        return 0

    import uvicorn

    from .app import create_app

    app = create_app(settings)
    print(f"TechRetail körs på http://{args.host}:{args.port}  (API-dokumentation: /docs)  Stoppa med Ctrl+C.")
    uvicorn.run(app, host=args.host, port=args.port, log_level="warning")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
